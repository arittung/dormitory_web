// output 변수를 null로 초기화
var output = '';
for (var i=0; i<10; i++) {
    console.log(output += '*');
}